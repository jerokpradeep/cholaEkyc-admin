import{_ as c,o as e,c as o}from"./index-6c4a6457.js";const n={},t={class:"p-3"};function r(s,a){return e(),o("div",t,"reconcellation")}const l=c(n,[["render",r]]);export{l as default};
