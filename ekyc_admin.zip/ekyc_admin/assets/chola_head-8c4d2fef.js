const a="/ekycadmin/assets/chola_head-505ae714.png";export{a as c};
