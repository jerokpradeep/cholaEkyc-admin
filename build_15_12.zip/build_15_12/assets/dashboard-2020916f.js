import{_ as c,o as e,c as s}from"./index-471713de.js";const o={},t={class:"p-3"};function a(r,n){return e(),s("div",t,"das")}const d=c(o,[["render",a]]);export{d as default};
