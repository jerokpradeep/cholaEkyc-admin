import{_ as e,o as c,c as o}from"./index-471713de.js";const s={},t={class:"p-3"};function a(n,r){return c(),o("div",t,"lead")}const d=e(s,[["render",a]]);export{d as default};
