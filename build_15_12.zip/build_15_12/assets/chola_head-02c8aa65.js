const e="/ekycadmin/assets/chola_head-e4ae5d06.svg";export{e as c};
