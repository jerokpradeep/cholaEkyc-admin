const s="/ekycadmin/assets/process-40c62bd6.svg",c="/ekycadmin/assets/Chevron-8c24d758.svg";export{s as P,c};
