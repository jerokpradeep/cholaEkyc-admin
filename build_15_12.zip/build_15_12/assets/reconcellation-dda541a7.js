import{_ as c,o as e,c as o}from"./index-471713de.js";const n={},t={class:"p-3"};function r(s,a){return e(),o("div",t,"reconcellation")}const l=c(n,[["render",r]]);export{l as default};
